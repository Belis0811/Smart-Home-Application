package com.example.smarthome;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.content.BroadcastReceiver;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Handler;

public class HumidtyConnect extends AppCompatActivity {
    private String TAG = "HumidtyConnect";
    @SuppressLint("StaticFieldLeak")
    public static Context context;
    private Button btnStartClient,btnCloseClient,btnSmart,btnplus,btnminus;
    private TextView status,tempnow,tempset,hotnow;
    private static TcpClient2 tcpClient =null;
    private MyBroadcastReceiver myBroadcastReceiver=new MyBroadcastReceiver();
    private MyBtnClicker myBtnClicker = new MyBtnClicker();
    private int h=50;
    private String m,m1;
    ExecutorService exec = Executors.newCachedThreadPool();

    private class MyBtnClicker implements View.OnClickListener{

        @Override
        public void onClick(View view_con) {
            switch (view_con.getId()){
                case R.id.button_connect:
                    Log.i(TAG, "onClick: 开始");
                    status.setText("已连接");
                    btnStartClient.setEnabled(false);
                    btnCloseClient.setEnabled(true);
                    btnSmart.setEnabled(true);
                    btnplus.setEnabled(true);
                    btnminus.setEnabled(true);
                    tcpClient = new TcpClient2("192.168.4.1",60000);
                    exec.execute(tcpClient);
                    break;
                case R.id.button_disconnect:
                    tcpClient.closeSelf();
                    btnStartClient.setEnabled(true);
                    btnCloseClient.setEnabled(false);
                    btnSmart.setEnabled(false);
                    btnplus.setEnabled(false);
                    btnminus.setEnabled(false);
                    status.setText("未连接");
                    break;
                case R.id.button16:
                            Message message = Message.obtain();
                            message.obj = "50%";
                            tempset.setText("50%");
                            exec.execute(new Runnable() {
                                @Override
                                public void run() {
                                    tcpClient.send("50%");
                                }
                            });
                    break;
                case R.id.button7:
                    Message message1 = Message.obtain();
                    h++;
                    message1.obj = h+"%";
                    tempset.setText(h+"%");
                    exec.execute(new Runnable() {
                        @Override
                        public void run() {
                            tcpClient.send(h+"%");
                        }
                    });
                    break;
                case R.id.button8:
                    Message message2 = Message.obtain();
                    h--;
                    message2.obj = h+"%";
                    tempset.setText(h+"%");
                    exec.execute(new Runnable() {
                        @Override
                        public void run() {
                            tcpClient.send(h+"%");
                        }
                    });
                    break;

            }
        }
    }


    private class MyBroadcastReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            String mAction = intent.getAction();
            switch (mAction){
                case "tcpClientReceiver":
                    String msg = intent.getStringExtra("tcpClientReceiver");
                    Message message = Message.obtain();
                    message.obj = msg;
                    m=msg.substring(6,8);
                    m1=msg.substring(3,5);
                    tempnow.setText(m+"%");
                    hotnow.setText(m1+"C");
                    break;
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.humidty_connected);
        context = this;
        bindReceiver();
        bindID();
        bindListener();
        Ini();
    }
    private void bindReceiver(){
        IntentFilter intentFilter = new IntentFilter("tcpClientReceiver");
        registerReceiver(myBroadcastReceiver,intentFilter);
    }
    private void bindID(){
        btnStartClient = (Button) findViewById(R.id.button_connect);
        btnCloseClient = (Button) findViewById(R.id.button_disconnect);
        btnSmart = (Button) findViewById(R.id.button16);
        btnplus=(Button) findViewById(R.id.button7);
        btnminus=(Button) findViewById(R.id.button8);
        status=(TextView) findViewById(R.id.TextSetTemp);
        tempset=(TextView) findViewById(R.id.textView9);
        tempnow=(TextView) findViewById(R.id.textView8);
        hotnow=(TextView) findViewById(R.id.textView14);
    }
    private void Ini(){
        btnCloseClient.setEnabled(false);
        btnSmart.setEnabled(false);
        btnplus.setEnabled(false);
        btnminus.setEnabled(false);
    }
    private void bindListener(){
        btnStartClient.setOnClickListener(myBtnClicker);
        btnCloseClient.setOnClickListener(myBtnClicker);
        btnSmart.setOnClickListener(myBtnClicker);
        btnplus.setOnClickListener(myBtnClicker);
        btnminus.setOnClickListener(myBtnClicker);
    }
}
