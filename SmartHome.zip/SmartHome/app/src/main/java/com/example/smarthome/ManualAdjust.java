package com.example.smarthome;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ManualAdjust extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual_mode);
    }
}
