package com.example.smarthome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;

public class MyActivity extends AppCompatActivity  {
    Button mybtn1,mybtn2,mybtn3,mybtn4;
    private ImageButton ib1,ib2;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my);
        mybtn1=(Button)findViewById(R.id.bt1);
        mybtn2=(Button)findViewById(R.id.bt2);
        mybtn3=(Button)findViewById(R.id.bt3);
        mybtn4=(Button)findViewById(R.id.bt4);
        mybtn1.setOnClickListener(new Personinfo());
        mybtn2.setOnClickListener(new functionintro());
        mybtn3.setOnClickListener(new law());
        mybtn4.setOnClickListener(new backmain());
        ib1=(ImageButton) findViewById(R.id.imageButton6);
        ib2=(ImageButton)findViewById(R.id.imageButton5);
        ib1.setOnClickListener(new turnlight());
        ib2.setOnClickListener(new turnhumidity());
    }

    class Personinfo implements OnClickListener{
        @Override
        public void onClick(View v1){
            Intent intent = new Intent(MyActivity.this, PI.class);
            startActivity(intent);
        }
    }

    class functionintro implements OnClickListener{
        @Override
        public void onClick(View v2){
            Intent intent = new Intent(MyActivity.this, FI.class);
            startActivity(intent);
        }
    }

    class law implements OnClickListener{
        @Override
        public void onClick(View v3){
            Intent intent = new Intent(MyActivity.this, LW.class);
            startActivity(intent);
        }
    }

    class backmain implements OnClickListener {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MyActivity.this, MainActivity.class);
            startActivity(intent);
        }
    }
    class turnlight implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MyActivity.this, LightModeActivity.class);
            startActivity(intent);
        }
    }

    class turnhumidity implements View.OnClickListener{
        @Override
        public void onClick(View v01){
            Intent intent = new Intent(MyActivity.this, HumidityActivity.class);
            startActivity(intent);
        }
    }
}
