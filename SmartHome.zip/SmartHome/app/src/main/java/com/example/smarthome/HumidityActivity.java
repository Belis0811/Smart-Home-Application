package com.example.smarthome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.ImageButton;
import android.widget.Toast;

public class HumidityActivity extends AppCompatActivity {
    private ImageButton ib1,ib2;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.humidity);
        btn1=(Button)findViewById(R.id.button12);
        btn1.setOnClickListener(new manual());
        ib1=(ImageButton) findViewById(R.id.imageButton);
        ib2=(ImageButton) findViewById(R.id.imageButton3);
        ib1.setOnClickListener(new turnmy());
        ib2.setOnClickListener(new turnlight());
    }

    class turnmy implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(HumidityActivity.this, MyActivity.class);
            startActivity(intent);
        }
    }


    class turnlight implements View.OnClickListener{
        @Override
        public void onClick(View v1) {
            Intent intent = new Intent(HumidityActivity.this, LightModeActivity.class);
            startActivity(intent);
    }
}
    class manual implements View.OnClickListener{
        @Override
        public void onClick(View v2){
            Intent intent=new Intent(HumidityActivity.this,HumidtyConnect.class);
            startActivity(intent);
        }
    }
}

