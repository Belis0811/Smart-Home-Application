package com.example.smarthome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.ImageButton;
import android.widget.Toast;


public class LightModeActivity extends AppCompatActivity {
    private ImageButton ib1,ib2;
    private Button btn1,btn2,btn3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lightmode);
        btn1=(Button)findViewById(R.id.button12);
        btn1.setOnClickListener(new connection());
        btn2=(Button)findViewById(R.id.button9);
        btn2.setOnClickListener(new sleepmode());
        btn3=(Button)findViewById(R.id.button10);
        btn3.setOnClickListener(new lightningmode());
        ib1=(ImageButton) findViewById(R.id.imageButton);
        ib2=(ImageButton)findViewById(R.id.imageButton5);
        ib1.setOnClickListener(new turnmy());
        ib2.setOnClickListener(new turnhumidity());
    }
    class sleepmode implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Toast.makeText(LightModeActivity.this, "睡眠模式已开启", Toast.LENGTH_SHORT).show();
        }
    }
    class lightningmode implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Toast.makeText(LightModeActivity.this, "照明模式已开启", Toast.LENGTH_SHORT).show();
        }
    }
    class turnmy implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(LightModeActivity.this, MyActivity.class);
            startActivity(intent);
        }
    }
    class turnhumidity implements View.OnClickListener{
        @Override
        public void onClick(View v01){
            Intent intent = new Intent(LightModeActivity.this, HumidityActivity.class);
            startActivity(intent);
        }
    }
    class connection implements View.OnClickListener{
        @Override
        public void onClick(View v02){
            Intent intent=new Intent(LightModeActivity.this,LightConnect.class);
            startActivity(intent);
        }
    }
}
