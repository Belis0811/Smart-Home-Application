package com.example.smarthome;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.content.BroadcastReceiver;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Handler;

public class LightConnect extends AppCompatActivity {

    private String TAG = "LightConnect";
    @SuppressLint("StaticFieldLeak")
    public static Context context;
    private Button btnStartClient, btnCloseClient, btnSmart,btnsleep,btnlighting;
    private static TcpClient tcpClient = null;
    private MyBroadcastReceiver myBroadcastReceiver = new MyBroadcastReceiver();
    private MyBtnClicker myBtnClicker = new MyBtnClicker();
    private TextView  status;
    private WifiManager wifiManager;
    private String ip,m="2";

    ExecutorService exec = Executors.newCachedThreadPool();

    private class MyBtnClicker implements View.OnClickListener {

        @Override
        public void onClick(View view_con) {
            switch (view_con.getId()) {
                case R.id.button_connect:
                    Log.i(TAG, "onClick: 开始");
                    status.setText("已连接");
                    btnStartClient.setEnabled(false);
                    btnCloseClient.setEnabled(true);
                    btnSmart.setEnabled(true);
                    btnlighting.setEnabled(true);
                    btnsleep.setEnabled(true);
                    tcpClient = new TcpClient("192.168.4.1", 60000);
                    exec.execute(tcpClient);
                    break;
                case R.id.button_disconnect:
                    tcpClient.closeSelf();
                    btnStartClient.setEnabled(true);
                    btnCloseClient.setEnabled(false);
                    btnSmart.setEnabled(false);
                    btnlighting.setEnabled(false);
                    btnsleep.setEnabled(false);
                    status.setText("未连接");
                    break;
                case R.id.button3:
                  switch (m) {
                      case "96":
                      Message message = Message.obtain();
                      message.obj = "off";
                      exec.execute(new Runnable() {
                          @Override
                          public void run() {
                              tcpClient.send("off");
                          }
                      });
                      break;
                     case "00":
                          Message message1 = Message.obtain();
                          message1.obj = "on";
                          exec.execute(new Runnable() {
                              @Override
                              public void run() {
                                  tcpClient.send("on");
                              }
                          });
                          break;

                  }
                        break;

                case R.id.button4:
                            Message message2 = Message.obtain();
                            message2.obj = "on";
                            exec.execute(new Runnable() {
                                @Override
                                public void run() {
                                    tcpClient.send("on");
                                }
                            });
                            break;
                case R.id.button5:
                    Message message3 = Message.obtain();
                    message3.obj = "off";
                    exec.execute(new Runnable() {
                        @Override
                        public void run() {
                            tcpClient.send("off");
                        }
                    });
                    break;



                    }

            }
        }



    private class MyBroadcastReceiver extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            String mAction = intent.getAction();
            switch (mAction){
                case "tcpClientReceiver":
                    String msg = intent.getStringExtra("tcpClientReceiver");
                    Message message = Message.obtain();
                    message.obj = msg;
                    m=msg.substring(0,2);
                    break;
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.connected_devices);
        /*wifiManager=(WifiManager)context.getSystemService(Context.WIFI_SERVICE);
        if(!wifiManager.isWifiEnabled()){
            wifiManager.setWifiEnabled(true);
        }
        WifiInfo wifiInfo=wifiManager.getConnectionInfo();
        ip=intToIP(wifiInfo.getIpAddress());*/
        context=this;
            bindReceiver();
            bindID();
            bindListener();
            Ini();

        }

        private void bindReceiver() {
            IntentFilter intentFilter = new IntentFilter("tcpClientReceiver");
            registerReceiver(myBroadcastReceiver, intentFilter);
        }

        private void bindID() {
            btnStartClient = (Button) findViewById(R.id.button_connect);
            btnCloseClient = (Button) findViewById(R.id.button_disconnect);
            btnSmart = (Button) findViewById(R.id.button3);
            btnsleep = (Button) findViewById(R.id.button5);
            btnlighting = (Button) findViewById(R.id.button4);
            status = (TextView) findViewById(R.id.TextSetTemp);
        /*txtRcv = (TextView) findViewById(R.id.recv);
        txtSend = (TextView) findViewById(R.id.send);*/
        }

        private void Ini() {
            btnCloseClient.setEnabled(false);
            btnSmart.setEnabled(false);
            btnlighting.setEnabled(false);
            btnsleep.setEnabled(false);
        }

        private void bindListener() {
            btnStartClient.setOnClickListener(myBtnClicker);
            btnCloseClient.setOnClickListener(myBtnClicker);
            btnSmart.setOnClickListener(myBtnClicker);
            btnsleep.setOnClickListener(myBtnClicker);
            btnlighting.setOnClickListener(myBtnClicker);
        }

        private String intToIP(int i) {
            return (i & 0xFF) + "." + ((i >> 8) & 0xFF) + "." + ((i >> 16) & 0xFF) + "." + ((i >> 24) & 0xFF);

        }
    }
